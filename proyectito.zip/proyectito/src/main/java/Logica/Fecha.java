/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

/**
 *
 * @author Estudiante
 */
public class Fecha {
    private int dia;
private int mes;
private int anio;
private int hora;
private int minuto;
public Fecha(int dia, int mes, int anio) {
this.dia = dia;
this.mes = mes;
this.anio = anio;
}
public void setdia (int dia){
this.dia = dia;
}
public int getdia(){
return dia;
}
public void setmes (int mes){
if (mes>0 && mes<13)
this.mes = mes;
}
public int getmes(){
return mes;
}
public void setanio (int anio){
this.anio = anio;
}
public int getanio(){
return anio;
}
public int getHora() {
return hora;
}
public void setHora(int hora) {
if (hora >0 && hora <25)
this.hora = hora;
}
public int getMinuto() {
return minuto;
}
public void setMinuto(int minuto) {
if (minuto >0 && minuto <60)
this.minuto = minuto;
}
}
