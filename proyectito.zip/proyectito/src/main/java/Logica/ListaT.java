/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;
 import Logica.Contacto;
/**
 *
 * @author facundovich anashe
 */
import java.util.ArrayList;
public class ListaT {
    private ArrayList<Tarea> tareas;
    private ArrayList<Contacto> contacto;
    
    public ListaT() {
        this.tareas = new ArrayList<Tarea>();
        this.contacto= new ArrayList<Contacto>();
    }

    public ArrayList<Tarea> getTareas() {
        return tareas;
    }

    public void setTareas(ArrayList<Tarea> tareas) {
        this.tareas = tareas;
    }

    public ArrayList<Contacto> getContacto() {
        return contacto;
    }

    public void setContacto(ArrayList<Contacto> contacto) {
        this.contacto = contacto;
    }
}
