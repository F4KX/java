/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

/**
 *
 * @author Estudiante
 */
public class Contacto {
    private String nombre;
    private String direccion;
    
    public Contacto() {
    }

    public Contacto(String nombrecompleto, String direccion) {
        this.nombre = nombrecompleto;
       
        this.direccion = direccion;
       
    }

    public String getNombrecompleto() {
        return nombre;
    }

    public void setNombrecompleto(String nombrecompleto) {
        this.nombre = nombrecompleto;
    }

    

    

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

   

    @Override
    public String toString() {
        return "Contacto{" + "nombre=" + nombre +  ", direccion=" + direccion + '}';
    } 
}
