/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import java.util.ArrayList;
import java.util.logging.Logger;

/**
 *
 * @author Estudiante
 */
public class Tarea {
    private String titulo;
    private int prioridad;
    private Fecha fecha;
    private boolean pendientes;
    private Contacto contacto;
    private ArrayList<Subtarea> subtareas;

    public Tarea() {
    }

    public Tarea(String titulo, int prioridad, Fecha fecha, boolean pendientes, Contacto contacto) {
        this.titulo = titulo;
        this.prioridad = prioridad;
        this.fecha = fecha;
        this.pendientes = pendientes;
        this.contacto = contacto;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public Fecha getFecha() {
        return fecha;
    }

    public void setFecha(Fecha fecha) {
        this.fecha = fecha;
    }

    public boolean isPendientes() {
        return pendientes;
    }

    public void setPendientes(boolean pendientes) {
        this.pendientes = pendientes;
    }

    public Contacto getContacto() {
        return contacto;
    }

    public void setContacto(Contacto contacto) {
        this.contacto = contacto;
    }

    public ArrayList<Subtarea> getSubtareas() {
        return subtareas;
    }

    public void setSubtareas(ArrayList<Subtarea> subtareas) {
        this.subtareas = subtareas;
    }
    

}
