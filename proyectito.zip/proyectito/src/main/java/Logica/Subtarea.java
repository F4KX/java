/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

/**
 *
 * @author facundovich anashe
 */
public class Subtarea {
    private String nombre;
    private boolean pendiente;
    private String descripcion;
  public Subtarea(String nombre, boolean pendiente, String descripcion) {
    this.pendiente = pendiente;
    this.nombre = nombre;
    this.descripcion = descripcion;
}

    public String getNombre() {
        return nombre;
    }

    public boolean isPendiente() {
        return pendiente;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPendiente(boolean pendiente) {
        this.pendiente = pendiente;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
  
}
