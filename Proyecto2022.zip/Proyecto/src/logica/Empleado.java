package logica;

public class Empleado {
    private String apellido;
    private String nombre;
    private double salario; //mensual
    
    public Empleado(String a,String b, double c){
        apellido = a;
        nombre = b;
        salario = c;
    }
    public Empleado(){
    }
    
     public void setApellido(String a){ 
        apellido = a;
    }
    public String getCodigo(){
        return apellido;
    }
    public void setNombre(String a){ 
        nombre = a;
    }
    public String getNombre(){
        return nombre;
    }
    public void setSalario(double a){ 
        salario = a;
    }
    public double getSalario(){
        return salario;
    }
    
    public double sueldoAnual(){
        return salario*13;
    }
    
    public void presentismo(){
        salario += salario * 0.10;
    }
    
    @Override
    public String toString(){
        return "Nombre completo: " + nombre + " " + apellido + ", Salario: mensual: $" + salario + ", anual: $" + sueldoAnual();
        
    }
    
}
