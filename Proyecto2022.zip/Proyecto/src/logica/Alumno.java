package logica;

public class Alumno {
    private String apellido;
    private int grupo;
    private double cuotaBase;
    
    public Alumno(String a,int b, double c){
        apellido = a;
        grupo = b;
        cuotaBase=c;
    }
    public Alumno(){
    }
    
    public void setApellido(String a){ 
        apellido = a;
    }
    public String getApellido(){
        return apellido;
    }
    public void setGrupo(int a){
        grupo=a;
    }
    public int getGrupo(){
        return grupo;
    }
    public void setCuotaBase(double a){
        cuotaBase=a;
    }
    public double getCuotaBase(){
        return cuotaBase;
    }
    public double cuotaNeta(){
        double monto= cuotaBase;
        switch(grupo){
            case 1: case 2:
                monto=cuotaBase*0.75;
                break;
            case 3: case 4:
                monto = cuotaBase*0.90;
                break;
        }
        return monto;
    }
    @Override
    public String toString(){
        return "apellido: " + apellido +", grupo: " + grupo +", cuota base: " + cuotaBase;
        
    }
}
