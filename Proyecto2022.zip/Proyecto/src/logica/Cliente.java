package logica;

public class Cliente {
    private String apellido;
    private int edad;       //en años
    private int antiguedad; //en meses
    private double sueldo;  //en pesos
    
    public Cliente(){
    }
    public Cliente(String a, int b, int c, double d){
        apellido = a;
        edad = b;
        antiguedad = c;
        sueldo = d;
    }
    
    final double requisitoSueldo = 20000;
    final int requisitoEdad = 18;
    final int requisitoAntiguedad = 6;
    
    final double limiteUno = 40000;
    final double porcentajeUno = 0.35;
    final double porcentajeDos = 0.50;
    
    public String getApellido() {
        return apellido;
    }
    
    public void setApellido(String x){
        apellido = x;
    }
    
    public int getEdad() {
        return edad;
    }
    
    public void setEdad(int x){
        edad = x;
    }
    
    public int getAntiguedad() {
        return antiguedad;
    }
    
    public void setAntiguedad(int x){
        antiguedad = x;
    }
    
    public double getSueldo() {
        return sueldo;
    }
    
    public void setSueldo(double x){
        sueldo = x;
    }
    
    public boolean darTarjeta(){
        boolean seDa = false;
        if ((edad >= requisitoEdad) && (sueldo > requisitoSueldo) && (antiguedad > requisitoAntiguedad)){
            seDa = true;
        }
        return seDa;
    }
    
    public double saldoTarjeta(){
        double saldo = 0;
        if (sueldo <= limiteUno) {
            saldo = (sueldo * porcentajeUno);
        } else if (sueldo > limiteUno) {
            saldo = (sueldo * porcentajeDos);
        }
        return saldo;
    }
    
    @Override
    public String toString(){
        return "Edad = " + edad + ", Antigüedad = " + antiguedad + ", Sueldo = " + sueldo + ", Elegible = " + darTarjeta();
    }
    
}