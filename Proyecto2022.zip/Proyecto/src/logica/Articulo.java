package logica;
public class Articulo {
    private String nombre;
    private int codigo;
    private double precioCosto;
    
    public Articulo(String a,int b, double c){
        nombre = a;
        codigo = b;
        precioCosto = c;
    }
    public Articulo(){
    }
    
     public void setCodigo(int a){ 
        codigo = a;
    }
    public int getCodigo(){
        return codigo;
    }
    public void setNombre(String a){ 
        nombre = a;
    }
    public String getNombre(){
        return nombre;
    }
    public void setPrecioCosto(double a){ 
        precioCosto = a;
    }
    public double getPrecioCosto(){
        return precioCosto;
        
    }
    public double precioVenta(){
        return precioCosto*1.20;
        
    }
    @Override
    public String toString(){
        return "nombre: " + nombre + ", codigo: " + codigo + ", precioCosto: " + precioCosto + ", precioVenta: " + precioVenta();
        
    }
    
}
