package paquete;
import logica.Alumno;
import logica.Articulo;
import logica.Cliente;
import logica.Empleado;
public class Principal {

    void inicio(){
        //probarAlumno();
        //probarArticulo();
        //probarCliente();
        probarEmpleado();
    }
    
    void probarAlumno(){
        Alumno a = new Alumno("Borges", 2, 0.0);
        System.out.println("Tu apellido es " + a.getApellido());
        System.out.println("Estás en el grupo " + a.getGrupo());
        System.out.println("Pagás $" + a.getCuotaBase() + " por esta garcada");
        System.out.println(a.toString());
    }
    
    void probarArticulo(){
        Articulo a = new Articulo("Agua de Peñarol", 1891, 20000.0);
        System.out.println("El código de " + a.getNombre() + " es " + a.getCodigo());
        System.out.println("Pagás $" + a.getPrecioCosto() + " por esta garcada");
        System.out.println("Y lo vendés por $" + a.precioVenta());
        System.out.println(a.toString());
    }
    
    void probarCliente(){
        Cliente a = new Cliente("Messi", 3, 36, 70000000000.0);
        Cliente b = new Cliente("Selby", 180, 2, 90000.0);
        Cliente c = new Cliente("Mortadelli", 30, 120, 19999.9);
        Cliente d = new Cliente("Solari", 73, 82, 1600000.0);
        
        chequearSaldo(a);
        chequearSaldo(b);
        chequearSaldo(c);
        chequearSaldo(d);
        
        System.out.println(a.toString());
        System.out.println(b.toString());
        System.out.println(c.toString());
        System.out.println(d.toString());
    }
    
    void chequearSaldo(Cliente x){
        if (x.darTarjeta()){
            System.out.println("Sr/a " + x.getApellido() + ": su saldo habilitado es: " + x.saldoTarjeta());
        } else {
            System.out.println("Sr/a " + x.getApellido() + ": disculpe, no cumple con los requisitos.");
        }
    }
    
    void probarEmpleado(){
        Empleado a = new Empleado("Sosa", "Martín", 10.0);
        System.out.println(a.toString());
        
    }
    
    public static void main(String[] args) {
        Principal p = new Principal();
        p.inicio();
    }
}
